package com.example.SpringJPAExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
