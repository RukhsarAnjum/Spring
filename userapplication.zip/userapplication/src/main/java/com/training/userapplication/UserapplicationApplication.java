package com.training.userapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserapplicationApplication.class, args);
	}

}
